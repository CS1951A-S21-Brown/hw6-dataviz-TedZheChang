renderGraph1(0, 2020)
renderGraph2("Global")
renderGraph3("All")